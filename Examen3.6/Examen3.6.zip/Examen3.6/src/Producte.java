public class Producte {
    protected String nom;

    public String getNom() {
        return nom;
    }

    public Producte(String nom) {
        this.nom = nom;
    }
}
