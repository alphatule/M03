public class Prestatge {
    private char pasadis;
    private Producte[] productes;

    public char getPasadis() {
        return pasadis;
    }

    public Prestatge(char pasadis) {
        this.pasadis = pasadis;
    }
}
