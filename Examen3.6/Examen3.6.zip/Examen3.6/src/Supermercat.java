public class Supermercat {
    private String nom;
    private Prestatge[] prestatges;

    public String getNom() {
        return nom;
    }

    public Supermercat(String nom) {
        this.nom = nom;
    }
}
